// ==========================================
// PROFESSOR CODER WEB APP
// Supabase Authentication and Project Portal
// ==========================================

const SUPABASE_URL = "https://nvsiebommgwxiukdjypx.supabase.co";
const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_kk7V_zDFxQSl0_HPBFhvBw_yFfL0jV3";

const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

// Application state
let authMode = "signup";
let currentUser = null;

// HTML elements
const authForm = document.getElementById("authForm");
const authMessage = document.getElementById("authMessage");
const authSubmit = document.getElementById("authSubmit");

const fullNameInput = document.getElementById("fullName");
const authEmailInput = document.getElementById("authEmail");
const authPasswordInput = document.getElementById("authPassword");

const signupTab = document.getElementById("signupTab");
const loginTab = document.getElementById("loginTab");

const accountDetails = document.getElementById("accountDetails");
const accountEmail = document.getElementById("accountEmail");
const logoutBtn = document.getElementById("logoutBtn");

const projectForm = document.getElementById("projectForm");
const projectMessage = document.getElementById("projectMessage");
const myProjects = document.getElementById("myProjects");

const menuBtn = document.getElementById("menuBtn");
const navigation = document.getElementById("navigation");

document.getElementById("year").textContent = new Date().getFullYear();

// ==========================================
// MOBILE NAVIGATION
// ==========================================

menuBtn.addEventListener("click", () => {
  navigation.classList.toggle("open");
});

navigation.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navigation.classList.remove("open");
  });
});

// ==========================================
// SWITCH BETWEEN SIGNUP AND LOGIN
// ==========================================

function setAuthMode(mode) {
  authMode = mode;

  const signingUp = mode === "signup";

  signupTab.classList.toggle("active", signingUp);
  loginTab.classList.toggle("active", !signingUp);

  fullNameInput.required = signingUp;
  fullNameInput.hidden = !signingUp;

  document.querySelector('label[for="fullName"]').hidden = !signingUp;

  authSubmit.textContent = signingUp ? "Create Account" : "Log In";

  authPasswordInput.autocomplete = signingUp
    ? "new-password"
    : "current-password";

  authMessage.textContent = "";
}

signupTab.addEventListener("click", () => {
  setAuthMode("signup");
});

loginTab.addEventListener("click", () => {
  setAuthMode("login");
});

// ==========================================
// REGISTER OR LOG IN
// ==========================================

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  authSubmit.disabled = true;
  authMessage.textContent = "Please wait...";

  try {
    const email = authEmailInput.value.trim();
    const password = authPasswordInput.value;
    const fullName = fullNameInput.value.trim();

    let result;

    if (authMode === "signup") {
      if (!fullName) {
        throw new Error("Please enter your full name.");
      }

      result = await db.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName
          }
        }
      });

      if (result.error) {
        throw result.error;
      }

      if (result.data.session) {
        authMessage.textContent = "Account created successfully!";

        await refreshAccount(result.data.session.user);
      } else {
        authMessage.textContent =
          "Account created. Check your email for the verification link, then log in.";

        setAuthMode("login");
      }
    } else {
      result = await db.auth.signInWithPassword({
        email,
        password
      });

      if (result.error) {
        throw result.error;
      }

      authMessage.textContent = "Login successful!";

      await refreshAccount(result.data.user);
    }
  } catch (error) {
    authMessage.textContent = error.message || "Something went wrong.";
  } finally {
    authSubmit.disabled = false;
  }
});

// ==========================================
// LOG OUT
// ==========================================

logoutBtn.addEventListener("click", async () => {
  logoutBtn.disabled = true;

  try {
    const { error } = await db.auth.signOut();

    if (error) throw error;

    authMessage.textContent = "You have logged out.";
  } catch (error) {
    authMessage.textContent = error.message;
  } finally {
    logoutBtn.disabled = false;
  }
});

// ==========================================
// UPDATE ACCOUNT INTERFACE
// ==========================================

async function refreshAccount(user) {
  currentUser = user || null;

  if (!currentUser) {
    accountDetails.hidden = true;
    authForm.hidden = false;

    myProjects.replaceChildren();

    const heading = document.createElement("h3");
    heading.textContent = "My Project Requests";

    const message = document.createElement("p");
    message.textContent = "Sign in to view your project submissions.";

    myProjects.append(heading, message);

    return;
  }

  accountDetails.hidden = false;
  authForm.hidden = true;

  accountEmail.textContent = currentUser.email || "";

  const profileName = currentUser.user_metadata?.full_name || "";

  document.getElementById("clientName").value = profileName;

  document.getElementById("clientEmail").value = currentUser.email || "";

  await loadMyProjects();
}

// ==========================================
// SUBMIT A PROJECT
// ==========================================

projectForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const submitButton = projectForm.querySelector('button[type="submit"]');

  if (!currentUser) {
    projectMessage.textContent =
      "Please create an account or log in before submitting a project.";

    document.getElementById("account").scrollIntoView({
      behavior: "smooth"
    });

    return;
  }

  if (!document.getElementById("termsAccepted").checked) {
    projectMessage.textContent = "Please acknowledge the terms and conditions.";

    return;
  }

  submitButton.disabled = true;
  projectMessage.textContent = "Submitting your project...";

  try {
    const project = {
      user_id: currentUser.id,

      client_name: document.getElementById("clientName").value.trim(),

      email: document.getElementById("clientEmail").value.trim(),

      project_title: document.getElementById("projectTitle").value.trim(),

      project_description: document
        .getElementById("projectDescription")
        .value.trim()
    };

    if (
      !project.client_name ||
      !project.email ||
      !project.project_title ||
      !project.project_description
    ) {
      throw new Error("Please complete all project fields.");
    }

    const { error } = await db.from("projects").insert(project);

    if (error) throw error;

    projectMessage.textContent =
      "Your project has been submitted successfully!";

    document.getElementById("projectTitle").value = "";
    document.getElementById("projectDescription").value = "";

    await loadMyProjects();
  } catch (error) {
    projectMessage.textContent = "Submission failed: " + error.message;
  } finally {
    submitButton.disabled = false;
  }
});

// ==========================================
// LOAD THE CLIENT'S PROJECTS
// ==========================================

async function loadMyProjects() {
  myProjects.replaceChildren();

  const heading = document.createElement("h3");
  heading.textContent = "My Project Requests";

  myProjects.appendChild(heading);

  if (!currentUser) {
    const message = document.createElement("p");

    message.textContent = "Log in to view your project submissions.";

    myProjects.appendChild(message);
    return;
  }

  const loading = document.createElement("p");
  loading.textContent = "Loading your projects...";

  myProjects.appendChild(loading);

  const { data, error } = await db
    .from("projects")
    .select("id, project_title, project_description, status, created_at")
    .eq("user_id", currentUser.id)
    .order("created_at", { ascending: false });

  myProjects.replaceChildren(heading);

  if (error) {
    const message = document.createElement("p");

    message.textContent = "Could not load projects: " + error.message;

    myProjects.appendChild(message);
    return;
  }

  if (!data || data.length === 0) {
    const message = document.createElement("p");

    message.textContent = "You haven't submitted any projects yet.";

    myProjects.appendChild(message);
    return;
  }

  data.forEach((project) => {
    const card = document.createElement("article");
    card.className = "project-item";

    const title = document.createElement("h3");
    title.textContent = project.project_title;

    const status = document.createElement("p");
    status.textContent = "Status: " + project.status;

    const description = document.createElement("p");
    description.textContent = project.project_description;

    const date = document.createElement("p");
    date.textContent = project.created_at
      ? "Submitted: " + new Date(project.created_at).toLocaleDateString()
      : "";

    card.append(title, status, description, date);

    myProjects.appendChild(card);
  });
}

// ==========================================
// RESTORE THE EXISTING SESSION
// ==========================================

async function initializeApp() {
  setAuthMode("signup");

  const { data, error } = await db.auth.getSession();

  if (error) {
    authMessage.textContent = "Could not restore session: " + error.message;

    return;
  }

  await refreshAccount(data.session?.user || null);
}

// Listen for login, logout and session changes.
db.auth.onAuthStateChange((event, session) => {
  if (
    event === "SIGNED_IN" ||
    event === "SIGNED_OUT" ||
    event === "USER_UPDATED"
  ) {
    // Defer other Supabase operations until after
    // the authentication callback completes.
    setTimeout(() => {
      refreshAccount(session?.user || null);
    }, 0);
  }
});

initializeApp();

// ======================================
// PROFESSOR CODER PRIVATE ADMIN DASHBOARD
// ======================================

const adminDashboard = document.getElementById("adminDashboard");
const adminProjectList = document.getElementById("adminProjectList");
const adminMessage = document.getElementById("adminMessage");
const adminSearch = document.getElementById("adminSearch");
const adminStatusFilter = document.getElementById("adminStatusFilter");
const adminRefreshBtn = document.getElementById("adminRefreshBtn");

let adminProjects = [];
let adminUserId = null;

const ADMIN_STATUSES = [
  "Pending",
  "Reviewing",
  "In Progress",
  "Completed",
  "Rejected"
];

function adminNotify(message) {
  adminMessage.textContent = message;
}
const { data: projects, error } = await db
.from("projects")
  .select(`
    id,
    client_name,
    email,
    project_title,
    status,
    quoted_amount,
    currency,
    quotation_status,
    payment_status,
    created_at
  `)
  .order("created_at", { ascending: false });

if (error) {
  console.error("Could not load admin projects:", error.message);
}
function adminElement(tag, className, text) {
  const element = document.createElement(tag);

  if (className) {
    element.className = className;
  }

  if (text !== undefined) {
    element.textContent = text;
  }

  return element;
}

function adminUpdateStats(projects) {
  document.getElementById("statTotal").textContent = projects.length;

  document.getElementById("statPending").textContent = projects.filter(
    (p) => p.status === "Pending"
  ).length;

  document.getElementById("statProgress").textContent = projects.filter(
    (p) => p.status === "In Progress"
  ).length;

  document.getElementById("statCompleted").textContent = projects.filter(
    (p) => p.status === "Completed"
  ).length;
}
const paidProjects = projects.filter(
  project => project.payment_status === "Paid"
).length;

const unpaidProjects = projects.filter(
  project => project.payment_status !== "Paid"
).length;

console.log("Paid projects:", paidProjects);
console.log("Unpaid projects:", unpaidProjects);
function adminRenderProjects() {
  // QUOTATION MANAGEMENT CONTROLS

  const quoteBox = adminElement("div", "admin-project-card");

  quoteBox.appendChild(adminElement("h4", "", "Project Quotation"));

  const amountInput = document.createElement("input");
  amountInput.type = "number";
  amountInput.min = "0";
  amountInput.step = "0.01";
  amountInput.placeholder = "Quotation amount";
  amountInput.value = project.quoted_amount ?? "";

  amountInput.setAttribute("aria-label", "Quotation amount");

  const currencySelect = document.createElement("select");

  [
    { value: "NGN", label: "NGN — Nigerian Naira" },
    { value: "USD", label: "USD — US Dollar" },
    { value: "GBP", label: "GBP — British Pound" }
  ].forEach((item) => {
    const option = document.createElement("option");
    option.value = item.value;
    option.textContent = item.label;
    currencySelect.appendChild(option);
  });

  currencySelect.value = ["NGN", "USD", "GBP"].includes(project.currency)
    ? project.currency
    : "NGN";

  const deadlineInput = document.createElement("input");
  deadlineInput.type = "date";
  deadlineInput.setAttribute("aria-label", "Project deadline");

  if (project.deadline) {
    deadlineInput.value = new Date(project.deadline).toISOString().slice(0, 10);
  }

  const saveQuoteButton = adminElement("button", "", "Save Quotation");

  saveQuoteButton.addEventListener("click", async () => {
    const amount = Number(amountInput.value);

    if (
      amountInput.value.trim() === "" ||
      !Number.isFinite(amount) ||
      amount < 0
    ) {
      adminNotify("Enter a valid quotation amount.");
      return;
    }

    let deadline = null;

    if (deadlineInput.value) {
      deadline = new Date(deadlineInput.value + "T23:59:59").toISOString();

      if (new Date(deadline) <= new Date()) {
        adminNotify("Choose a future deadline.");
        return;
      }
    }

    saveQuoteButton.disabled = true;
    adminNotify("Saving quotation...");

    try {
      const { data, error } = await db.rpc("admin_update_project_quote", {
        p_project_id: project.id,
        p_amount: amount,
        p_currency: currencySelect.value,
        p_deadline: deadline
      });

      if (error) throw error;

      if (!data || data.success !== true) {
        throw new Error("Quotation could not be saved.");
      }

      adminNotify("Quotation saved. The client has been notified.");

      await adminLoadProjects();
    } catch (error) {
      console.error("Quotation update error:", error);

      adminNotify(error.message || "Unable to save quotation.");

      saveQuoteButton.disabled = false;
    }
  });

  quoteBox.appendChild(amountInput);
  quoteBox.appendChild(currencySelect);
  quoteBox.appendChild(deadlineInput);
  quoteBox.appendChild(saveQuoteButton);

  card.appendChild(quoteBox);

  adminProjectList.replaceChildren();

  const searchTerm = adminSearch.value.trim().toLowerCase();
  const statusFilter = adminStatusFilter.value;

  const filteredProjects = adminProjects.filter((project) => {
    const searchableText = [
      project.client_name,
      project.email,
      project.project_title,
      project.project_description
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    const matchesSearch = searchableText.includes(searchTerm);

    const matchesStatus =
      statusFilter === "All" || project.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  if (filteredProjects.length === 0) {
    adminProjectList.appendChild(
      adminElement("p", "", "No projects match your search or filter.")
    );

    return;
  }

  filteredProjects.forEach((project) => {
    const card = adminElement("article", "admin-project-card");

    card.appendChild(
      adminElement("h4", "", project.project_title || "Untitled project")
    );

    card.appendChild(
      adminElement(
        "p",
        "admin-project-meta",
        "Client: " + (project.client_name || "Not provided")
      )
    );

    card.appendChild(
      adminElement(
        "p",
        "admin-project-meta",
        "Email: " + (project.email || "Not provided")
      )
    );

    const date = project.created_at
      ? new Date(project.created_at).toLocaleString()
      : "Date unavailable";

    card.appendChild(
      adminElement("p", "admin-project-meta", "Submitted: " + date)
    );

    card.appendChild(
      adminElement(
        "p",
        "",
        project.project_description || "No description supplied."
      )
    );

    card.appendChild(
      adminElement(
        "p",
        "admin-project-meta",
        "Current status: " + (project.status || "Pending")
      )
    );

    const controls = adminElement("div", "admin-status-controls");

    const select = document.createElement("select");
    select.setAttribute("aria-label", "Choose project status");

    ADMIN_STATUSES.forEach((status) => {
      const option = document.createElement("option");
      option.value = status;
      option.textContent = status;
      select.appendChild(option);
    });

    const currentStatus = ADMIN_STATUSES.includes(project.status)
      ? project.status
      : "Pending";

    select.value = currentStatus;

    const saveButton = adminElement("button", "", "Save Status");

    saveButton.addEventListener("click", async () => {
      if (!adminUserId) {
        adminNotify("Please sign in again.");
        return;
      }

      const newStatus = select.value;

      saveButton.disabled = true;
      adminNotify("Updating project status...");

      try {
        const { data, error } = await db
          .from("projects")
          .update({ status: newStatus })
          .eq("id", project.id)
          .select("id, status");

        if (error) {
          throw error;
        }

        if (!data || data.length === 0) {
          throw new Error(
            "No project was updated. Check your admin role and database policies."
          );
        }

        project.status = newStatus;

        adminUpdateStats(adminProjects);
        adminRenderProjects();
        adminNotify("Project status updated successfully.");
      } catch (error) {
        console.error("Admin status update failed:", error);
        adminNotify(error.message || "Could not update project status.");
        saveButton.disabled = false;
      }
    });

    controls.appendChild(select);
    controls.appendChild(saveButton);
    card.appendChild(controls);
    adminProjectList.appendChild(card);
  });
}

async function adminLoadProjects() {
  if (!adminUserId) {
    return;
  }

  adminRefreshBtn.disabled = true;
  adminNotify("Loading client projects...");

  try {
    const { data, error } = await db
      .from("projects")
      .select(
        "id, client_name, email, project_title, project_description, status, created_at, user_id"
      )
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    adminProjects = data || [];

    adminUpdateStats(adminProjects);
    adminRenderProjects();

    adminNotify("Loaded " + adminProjects.length + " project(s).");
  } catch (error) {
    console.error("Could not load admin projects:", error);

    adminProjects = [];
    adminUpdateStats([]);

    adminProjectList.replaceChildren(
      adminElement(
        "p",
        "",
        "Unable to load projects. Check your admin role, RLS policies, and database table columns."
      )
    );

    adminNotify(error.message || "Unable to load projects.");
  } finally {
    adminRefreshBtn.disabled = false;
  }
}

async function adminCheckAccess(session) {
  adminDashboard.hidden = true;
  adminUserId = null;
  adminProjects = [];

  if (!session || !session.user) {
    return;
  }

  // app_metadata is managed by trusted administrators.
  // Do not use user-editable user_metadata for admin authorization.
  const user = session.user;

  if (user.app_metadata?.role !== "admin") {
    return;
  }

  adminUserId = user.id;
  adminDashboard.hidden = false;

  await adminLoadProjects();
}

// Search and filtering
adminSearch.addEventListener("input", adminRenderProjects);
adminStatusFilter.addEventListener("change", adminRenderProjects);

adminRefreshBtn.addEventListener("click", adminLoadProjects);

// Initial session check
(async function initializeAdminDashboard() {
  const { data, error } = await db.auth.getSession();

  if (error) {
    console.error("Could not check session:", error);
    return;
  }

  await adminCheckAccess(data.session);
})();

// React to sign-in and sign-out.
db.auth.onAuthStateChange((_event, session) => {
  // Defer async work so it does not interfere with Supabase auth callbacks.
  setTimeout(() => {
    adminCheckAccess(session);
  }, 0);
});

// Show the admin navigation button only to administrators.
const adminAccessBtn = document.getElementById("adminAccessBtn");

async function updateAdminNavigation() {
  const { data, error } = await db.auth.getSession();

  if (error || !data.session) {
    adminAccessBtn.hidden = true;
    return;
  }

  const isAdmin = data.session.user.app_metadata?.role === "admin";

  adminAccessBtn.hidden = !isAdmin;
}

adminAccessBtn.addEventListener("click", () => {
  const dashboard = document.getElementById("adminDashboard");

  if (dashboard) {
    dashboard.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }
});

updateAdminNavigation();

db.auth.onAuthStateChange(() => {
  setTimeout(updateAdminNavigation, 0);
});

// =====================================
// PROFESSOR CODER CLIENT DASHBOARD
// =====================================

const clientDashboard = document.getElementById("clientDashboard");
const clientMessage = document.getElementById("clientMessage");
const clientProjectList = document.getElementById("clientProjectList");
const clientNotifications = document.getElementById("clientNotifications");
const clientRefreshBtn = document.getElementById("clientRefreshBtn");

let clientDashboardUserId = null;

function clientText(tag, className, value) {
  const el = document.createElement(tag);

  if (className) el.className = className;

  if (value !== undefined) {
    el.textContent = value;
  }

  return el;
}

function clientNotify(message, isError = false) {
  clientMessage.textContent = message;
  clientMessage.className = isError ? "client-message-error" : "";
}

async function loadMyClientProjects() {
  if (!clientDashboardUserId) return;

  clientProjectList.replaceChildren(
    clientText("p", "", "Loading your projects...")
  );

  try {
    const { data: projects, error } = await db
      .from("projects")
      .select(
        const paymentButton = document.createElement("button
paymentButton.type = "button";
paymentButton.className = "client-portal-button";

const quotationAccepted =
  project.quotation_status === "Accepted";

const paymentComplete =
  String(project.payment_status || "").toLowerCase() === "paid";

const validAmount =
  Number.isFinite(Number(project.quoted_amount)) &&
  Number(project.quoted_amount) > 0;

if (paymentComplete) {
  paymentButton.textContent = "Payment Completed";
  paymentButton.disabled = true;
} else if (quotationAccepted && validAmount) {
  paymentButton.textContent = "Pay Now";

  paymentButton.addEventListener("click", () => {
    initializeProjectPayment(project.id, paymentButton);
  });
} else if (!quotationAccepted) {
  paymentButton.textContent = "Accept Quotation First";
  paymentButton.disabled = true;
} else {
  paymentButton.textContent = "Quotation Required";
  paymentButton.disabled = true;
}

card.append(
  title,
  description,
  workflow,
  completion,
  quotation,
  quoteStatus,
  payment,
  deadline,
  projectId,
  paymentButton
);

projectList.appendChild(card);
      )
      .eq("user_id", clientDashboardUserId)
      .order("created_at", { ascending: false });

if (
  project.quotation_status === "Accepted" &&
  project.payment_status !== "Paid" &&
  Number(project.quoted_amount) > 0
) {
  const payButton = document.createElement("button");

  payButton.textContent = "Pay Now";

  payButton.addEventListener("click", () => {
    startProjectPayment(project.id);
  });

 card.appendChild(payButton);
}
    if (
  String(project.payment_status || "").trim().toLowerCase() === "paid"
) {
  const paymentMessage = clientText(
    "p,client-status",
    "Payment confirmed"          card.appendChild(paymentMessage);
  }
    
    if (error) throw error;

    const list = projects || [];

    document.getElementById("clientTotal").textContent = list.length;

    document.getElementById("clientInProgress").textContent = list.filter(
      (p) => p.status === "In Progress"
    ).length;

    document.getElementById("clientCompleted").textContent = list.filter(
      (p) => p.status === "Completed"
    ).length;

    clientProjectList.replaceChildren();

    if (!list.length) {
      clientProjectList.appendChild(
        clientText("p", "", "You have not submitted any projects yet.")
      );
    }

    list.forEach((project) => {
      const card = clientText("article", "client-project-card");

      card.appendChild(
        clientText("h4", "", project.project_title || "Untitled project")
      );

      card.appendChild(
        clientText(
          "p",
          "",
          project.project_description || "No description provided."
        )
      );

      card.appendChild(
        clientText("span", "client-status", project.status || "Pending")
      );

      const submitted = project.created_at
        ? new Date(project.created_at).toLocaleString()
        : "Not available";

      card.appendChild(
        clientText("p", "client-muted", "Submitted: " + submitted)
      );

      if (project.deadline) {
        card.appendChild(
          clientText(
            "p",
            "client-muted",
            "Deadline: " + new Date(project.deadline).toLocaleDateString()
          )
        );
      }

      if (
        project.quoted_amount !== null &&
        project.quoted_amount !== undefined
      ) {
        const quote = clientText("div", "client-quotation");

        quote.appendChild(
          clientText(
            "p",
            "",
            "Quotation: " +
              Number(project.quoted_amount).toLocaleString() +
              " " +
              (project.currency || "NGN")
          )
        );

        quote.appendChild(
          clientText(
            "p",
            "client-muted",
            "Quotation status: " + (project.quotation_status || "Not Prepared")
          )
        );

        card.appendChild(quote);
        // Allow clients to respond to prepared quotations.

        if (project.quotation_status === "Prepared") {
          const responseBox = document.createElement("div");

          // ... preceding code above line 40 ...

const acceptButton = clientText(
  "button",
  "",
  "Accept Quotation"
);

const declineButton = clientText(
  "button",
  "",
  "Decline Quotation"
);

// IMPORTANT: If this whole block was inside a outer function or event listener, 
// close it with a '}' before defining respondToQuotation:
//} 

async function respondToQuotation(response){                          acceptButton.disabled = truedeclineButton.disabled = true;                               try }                               const { data, error } = await db.rpc(
  
  "client_respond_to_quote",
      { response_status: response }
    );

    if (error) throw error;
  } catch (error) {
    console.error("Error responding to quote:", error);
  } finally {
    acceptButton.disabled = false;
    declineButton.disabled = false;
  }
}

          acceptButton.addEventListener("click", () => {
            if (confirm("Do you want to accept this quotation?")) {
              respondToQuotation("Accepted");
            }
          });

          declineButton.addEventListener("click", () => {
            if (confirm("Do you want to decline this quotation?")) {
              respondToQuotation("Declined");
            }
          });

          responseBox.appendChild(acceptButton);
          responseBox.appendChild(declineButton);

          quote.appendChild(responseBox);
        }
      }

      clientProjectList.appendChild(card);
    });

    clientNotify("Your project dashboard is up to date.");
  } catch (error) {
    console.error("Client project loading error:", error);

    clientProjectList.replaceChildren(
      clientText(
        "p",
        "client-message-error",
        "We could not load your projects. Please try again."
      )
    );

    clientNotify(
      "Unable to load projects. Please check your connection.",
      true
    );
  } // <-- Closes the catch block cleanly

async function loadMyNotifications() {
  if (!clientDashboardUserId) return;

  try {
    const { data, error } = await db
      .from("notifications")
      .select("id, title, message, is_read, created_at")
      .eq("user_id", clientDashboardUserId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    
    // ... render notifications ...
  } catch (err) {
    console.error("Notifications error:", err);
  }
}

    clientNotifications.replaceChildren();

    if (!data || data.length === 0) {
      clientNotifications.appendChild(
        clientText("p", "", "You have no notifications yet.")
      );
      return;
    }

    data.forEach((notification) => {
      const card = clientText("article", "client-notification-card");

      card.appendChild(clientText("strong", "", notification.title));
card.appendChild(
  createPaymentBadge(project.payment_status)
);
      card.appendChild(clientText("p", "", notification.message));

      card.appendChild(
        clientText(
          "p",
          "client-muted",
          new Date(notification.created_at).toLocaleString() +
            (notification.is_read ? " · Read" : " · Unread")
        )
      );

      if (!notification.is_read) {
        const button = clientText("button", "", "Mark as read");

        button.addEventListener("click", async () => {
          button.disabled = true;

          const { error: updateError } = await db
            .from("notifications")
            .update({ is_read: true })
            .eq("id", notification.id)
            .eq("user_id", clientDashboardUserId);

          if (updateError) {
            button.disabled = false;
            clientNotify("Could not mark notification as read.", true);
            return;
          }

          notification.is_read = true;
          await loadMyNotifications();
        });

        card.appendChild(button);
      }

      clientNotifications.appendChild(card);
    }
  } catch (error) {
    console.error("Notification loading error:", error);

    clientNotifications.replaceChildren(
      clientText(
        "p",
        "client-message-error",
        "Notifications are temporarily unavailable."
      )
    );
async function refreshClientDashboard() {
  const { data, error } = await db.auth.getSession();

  if (error || !data.session) {
    clientDashboard.hidden = true;
    clientDashboardUserId = null;
    return;
  }

  clientDashboardUserId = data.session.user.id;
  clientDashboard.hidden = false;

  await Promise.all([loadMyClientProjects(), loadMyNotifications()]);
}

clientRefreshBtn.addEventListener("click", refreshClientDashboard);

// Initialize the dashboard when the page loads.
refreshClientDashboard();

// Refresh the dashboard when authentication changes.
db.auth.onAuthStateChange((_event, session) => {
  setTimeout(async () => {
    if (!session) {
      clientDashboardUserId = null;
      clientDashboard.hidden = true;
      return;
    }

    await refreshClientDashboard();
  }, 0);
});

async function startProjectPayment(projectId) {
  const paymentMessage =
    document.getElementById("paymentMessage");

  paymentMessage.textContent = "Preparing secure checkout...";

  try {
    const {
      data: { session },
      error: sessionError,
    } = await db.auth.getSession();

    if (sessionError || !session) {
      throw new Error("Please sign in before paying.");
    }

    const { data, error } = await db.functions.invoke(
      "initialize-payment",
      {
        body: {
          project_id: projectId,
        },
      }
    );

    if (error) throw error;

    if (!data?.authorization_url) {
      throw new Error(
        data?.error || "Could not start payment."
      );
    }

    window.location.href = data.authorization_url;

  } catch (error) {
    console.error("Payment initiation error:", error);

    paymentMessage.textContent =
      error.message || "Unable to start payment.";
  }
}

async function verifyReturnedPayment() {
  const message = document.getElementById("paymentMessage");
  const params = new URLSearchParams(window.location.search);
  const reference =
    params.get("reference") || params.get("trxref");

  if (!reference) return;

  if (message) {
    message.textContent = "Verifying your payment securely...";
  }

  try {
    const {
      data: { session },
      error: sessionError
    } = await db.auth.getSession();

    if (sessionError || !session) {
      throw new Error(
        "Please sign in with the account used to make this payment."
      );
    }

    const { data, error } = await db.functions.invoke(
      "verify-payment",
      { body: { reference } }
    );

    if (error) throw error;

    if (data?.status === "paid" && data?.success) {
      if (message) {
        message.textContent =
          "Payment confirmed! Your project payment has been recorded.";
      }

      // Reload project information so the Paid status appears.
      if (typeof loadClientProjects === "function") {
        await loadClientProjects();
      }

      // Remove the payment reference from the browser URL.
      window.history.replaceState(
        {},
        document.title,
        window.location.pathname
      );
    } else {
      if (message) {
        message.textContent =
          data?.message ||
          "Payment is not confirmed yet. Please check again shortly.";
      }
    }
  } catch (error) {
    console.error("Payment verification error:", error);

    if (message) {
      message.textContent =
        error.message || "Unable to verify payment right now.";
    }
  }
}

// Run this after the page and Supabase client are initialized.
verifyReturnedPayment();
function createPaymentBadge(paymentStatus) {
  const badge = document.createElement("span");

  badge.textContent =
    paymentStatus === "Paid" ? "Payment Confirmed" : "Payment Pending";

  badge.style.display = "inline-block";
  badge.style.padding = "6px 12px";
  badge.style.borderRadius = "20px";
  badge.style.fontSize = "12px";
  badge.style.fontWeight = "bold";

  return badge;
}
async function uploadProjectDeliverables() {
  const projectInput = document.getElementById("deliveryProjectId");
  const fileInput = document.getElementById("deliveryFiles");
  const message = document.getElementById("deliveryMessage");
  const button = document.getElementById("uploadDeliveryButton");

  const projectId = projectInput.value.trim();
  const files = Array.from(fileInput.files || []);

  const allowedExtensions = [
    "zip",
    "pdf",
    "png",
    "jpg",
    "jpeg",
    "txt"
  ];

  const maxFileSize = 10 * 1024 * 1024;

  try {
    if (!projectId) {
      throw new Error("Enter the project ID first.");
    }

    if (!files.length) {
      throw new Error("Choose at least one file.");
    }

    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in first.");
    }

    if (user.app_metadata?.role !== "admin") {
      throw new Error("Administrator access is required.");
    }

    const { data: project, error: projectError } = await db
      .from("projects")
      .select("id, user_id, project_title")
      .eq("id", projectId)
      .single();

    if (projectError || !project) {
      throw new Error("Project not found. Check the project ID.");
    }

    for (const file of files) {
      const extension = file.name.split(".").pop()?.toLowerCase();

      if (!extension || !allowedExtensions.includes(extension)) {
        throw new Error(
          `File type not allowed: ${file.name}. Upload ZIP, PDF, PNG, JPG, JPEG, or TXT files.`
        );
      }

      if (file.size > maxFileSize) {
        throw new Error(
          `${file.name} exceeds the 10 MB file-size limit.`
        );
      }

      if (file.size === 0) {
        throw new Error(`${file.name} is empty.`);
      }
    }

    button.disabled = true;
    message.textContent = "Uploading project files...";

    for (const file of files) {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const storagePath =
        `${project.id}/${crypto.randomUUID()}-${safeName}`;

      const { error: uploadError } = await db.storage
        .from("project-deliveries")
        .upload(storagePath, file, {
          cacheControl: "3600",
          upsert: false
        });

      if (uploadError) {
        throw new Error(
          `Could not upload ${file.name}: ${uploadError.message}`
        );
      }

      const { error: recordError } = await db
        .from("project_deliveries")
        .insert({
          project_id: project.id,
          client_id: project.user_id,
          uploaded_by: user.id,
          file_name: file.name,
          storage_path: storagePath,
          file_size: file.size,
          content_type: file.type || "application/octet-stream",
          delivery_status: "Delivered"
        });

      if (recordError) {
        // Remove the uploaded object if its database record could not be saved.
        await db.storage
          .from("project-deliveries")
          .remove([storagePath]);

        throw new Error(
          `The file uploaded, but its delivery record could not be saved: ${recordError.message}`
        );
      }
    }

    message.textContent =
      "Success! Your project deliverables have been uploaded.";

    fileInput.value = "";
  } catch (error) {
    console.error("Delivery upload error:", error);
    message.textContent = error.message || "Upload failed.";
  } finally {
    button.disabled = false;
  }
}

document
  .getElementById("uploadDeliveryButton")
  .addEventListener("click", uploadProjectDeliverables);
async function loadClientDeliveries() { downloadButton.addEventListener("click", async () => {
  downloadButton.disabled = true;

  try {
    await downloadProjectDelivery(delivery.id);
  } finally {
    downloadButton.disabled = false;
  }
});
                                       const acceptButton = document.createElement("button");
acceptButton.textContent = "Accept Delivery";

acceptButton.addEventListener("click", () => {
  respondToDelivery(delivery.id, "Accepted");
});

const revisionButton = document.createElement("button");
revisionButton.textContent = "Request Revision";

revisionButton.addEventListener("click", () => {
  respondToDelivery(delivery.id, "Revision Requested");
});

if (delivery.delivery_status !== "Accepted") {
  card.append(acceptButton, revisionButton);
}
  const list = document.getElementById("deliveryList");
  const message = document.getElementById("clientDeliveryMessage");

  list.replaceChildren();
  message.textContent = "Loading your project files...";

  try {
    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in to view your deliverables.");
    }

    const { data: deliveries, error } = await db
      .from("project_deliveries")
      .select(
        "id, project_id, file_name, file_size, delivery_status, created_at"
      )
      .eq("client_id", user.id)
      .order("created_at", { ascending: false });

    if (error) throw error;

    if (!deliveries || deliveries.length === 0) {
      message.textContent = "No project deliverables are available yet.";
      return;
    }

    for (const delivery of deliveries) {
      const card = document.createElement("article");

      const title = document.createElement("h3");
      title.textContent = delivery.file_name;

      const status = document.createElement("p");
      status.textContent = `Status: ${delivery.delivery_status}`;

      const downloadButton = document.createElement("button");
      downloadButton.textContent = "Download File";

      downloadButton.addEventListener("click", async () => {
        downloadButton.disabled = true;

        try {
          // A secure download function will be connected in the next step.
          message.textContent =
            "Secure downloads are being connected. Please try again after setup.";

        } finally {
          downloadButton.disabled = false;
        }
      });

      card.append(title, status, downloadButton);
      list.appendChild(card);
    }

    message.textContent = "";
  } catch (error) {
    console.error("Delivery loading error:", error);
    message.textContent = error.message || "Unable to load deliverables.";
  }
}
async function downloadProjectDelivery(deliveryId) {
  const message = document.getElementById("clientDeliveryMessage");

  try {
    message.textContent = "Preparing your secure download...";

    const {
      data: { session },
      error: sessionError,
    } = await db.auth.getSession();

    if (sessionError || !session) {
      throw new Error("Please sign in to download your files.");
    }

    const { data, error } = await db.functions.invoke(
      "download-project-file",
      {
        body: {
          delivery_id: deliveryId,
        },
      }
    );

    if (error) throw error;

    if (!data?.success || !data?.download_url) {
      throw new Error(data?.error || "Unable to prepare the download.");
    }

    // Open the short-lived signed URL.
    window.location.assign(data.download_url);

    message.textContent =
      `Your download is starting: ${data.file_name}`;
  } catch (error) {
    console.error("Download error:", error);

    message.textContent =
      error.message || "Could not download the file.";
  }
}
async function respondToDelivery(deliveryId, feedbackType) {
  const message = document.getElementById(
    "deliveryFeedbackMessage"
  );

  const feedbackInput = document.getElementById(
    "revisionFeedback"
  );

  const feedbackMessage = feedbackInput.value.trim();

  if (
    feedbackType === "Revision Requested" &&
    !feedbackMessage
  ) {
    message.textContent =
      "Please describe the changes you need.";
    return;
  }

  try {
    message.textContent = "Submitting your response...";

    const { data, error } = await db.functions.invoke(
      "respond-to-delivery",
      {
        body: {
          delivery_id: deliveryId,
          feedback_type: feedbackType,
          feedback_message:
            feedbackType === "Revision Requested"
              ? feedbackMessage
              : null
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(
        data?.error || "Could not submit your response."
      );
    }

    message.textContent = data.message;

    if (feedbackType === "Revision Requested") {
      feedbackInput.value = "";
    }

    if (typeof loadClientDeliveries === "function") {
      await loadClientDeliveries();
    }
  } catch (error) {
    console.error("Delivery response error:", error);

    message.textContent =
      error.message || "Unable to submit your response.";
  }
}
async function loadAdminRevisionRequests() {
  const list = document.getElementById("adminRevisionList");
  const message = document.getElementById("adminRevisionMessage");

  list.replaceChildren();
  message.textContent = "Loading revision requests...";

  try {
    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in first.");
    }

    if (user.app_metadata?.role !== "admin") {
      throw new Error("Administrator access required.");
    }

    const { data, error } = await db.functions.invoke(
      "admin-manage-deliveries",
      {
        body: {
          action: "list_feedback"
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(data?.error || "Could not load revisions.");
    }

    const feedback = data.feedback || [];

    if (feedback.length === 0) {
      message.textContent = "There are no revision requests.";
      return;
    }

    for (const item of feedback) {
      const card = document.createElement("article");

      const heading = document.createElement("h3");
      heading.textContent = "Revision Request";

      const project = document.createElement("p");
      project.textContent = `Project ID: ${item.project_id}`;

      const delivery = document.createElement("p");
      delivery.textContent = `Delivery ID: ${item.delivery_id}`;

      const client = document.createElement("p");
      client.textContent = `Client ID: ${item.client_id}`;

      const feedbackText = document.createElement("p");
      feedbackText.textContent =
        item.feedback_message || "No additional details supplied.";

      const date = document.createElement("p");
      date.textContent = `Submitted: ${
        new Date(item.created_at).toLocaleString()
      }`;

      const statusLabel = document.createElement("label");
      statusLabel.textContent = "Update delivery status ";

      const statusSelect = document.createElement("select");

      for (const status of [
        "Revision Requested",
        "Revision In Progress",
        "Delivered",
        "Accepted"
      ]) {
        const option = document.createElement("option");
        option.value = status;
        option.textContent = status;
        statusSelect.appendChild(option);
      }

      statusSelect.value = "Revision Requested";

      const updateButton = document.createElement("button");
      updateButton.type = "button";
      updateButton.textContent = "Save Status";

      updateButton.addEventListener("click", async () => {
        updateButton.disabled = true;

        try {
          const { data: result, error: updateError } =
            await db.functions.invoke("admin-manage-deliveries", {
              body: {
                action: "update_delivery_status",
                delivery_id: item.delivery_id,
                status: statusSelect.value
              }
            });

          if (updateError) throw updateError;

          if (!result?.success) {
            throw new Error(
              result?.error || "Could not update status."
            );
          }

          message.textContent = result.message;
        } catch (error) {
          console.error("Status update error:", error);
          message.textContent =
            error.message || "Could not update delivery status.";
        } finally {
          updateButton.disabled = false;
        }
      });

      statusLabel.appendChild(statusSelect);

      card.append(
        heading,
        project,
        delivery,
        client,
        feedbackText,
        date,
        statusLabel,
        updateButton
      );

      list.appendChild(card);
    }

    message.textContent =
      `${feedback.length} revision request(s) loaded.`;
  } catch (error) {
    console.error("Admin revision loading error:", error);
    message.textContent =
      error.message || "Unable to load revision requests.";
  }
}

document
  .getElementById("loadRevisionRequests")
  .addEventListener("click", loadAdminRevisionRequests);
async function manageProjectCompletion(action) {
  const projectId = document
    .getElementById("completionProjectId")
    .value.trim();

  const summary = document
    .getElementById("completionSummary")
    .value.trim();

  const message = document.getElementById("completionMessage");

  if (!projectId) {
    message.textContent = "Enter a project ID.";
    return;
  }

  try {
    message.textContent = "Processing request...";

    const { data, error } = await db.functions.invoke(
      "project-completion",
      {
        body: {
          action,
          project_id: projectId,
          summary
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(data?.error || "Unable to update project.");
    }

    message.textContent = data.message;
  } catch (error) {
    console.error("Project completion error:", error);
    message.textContent =
      error.message || "An error occurred.";
  }
}

document
  .getElementById("requestClientReviewButton")
  .addEventListener("click", () => {
    manageProjectCompletion("request_client_review");
  });

document
  .getElementById("markProjectCompletedButton")
  .addEventListener("click", () => {
    manageProjectCompletion("mark_completed");
  });
async function submitProjectReview() {
  const projectId = document
    .getElementById("projectReviewId")
    .value.trim();

  const rating = Number(
    document.getElementById("projectRating").value
  );

  const reviewText = document
    .getElementById("projectReviewText")
    .value.trim();

  const message = document.getElementById("projectReviewMessage");

  if (!projectId) {
    message.textContent = "Enter your project ID.";
    return;
  }

  try {
    message.textContent = "Submitting your review...";

    const { data, error } = await db.functions.invoke(
      "project-completion",
      {
        body: {
          action: "submit_review",
          project_id: projectId,
          rating,
          review_text: reviewText
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(data?.error || "Could not submit review.");
    }

    message.textContent = data.message;

    document.getElementById("projectReviewText").value = "";
  } catch (error) {
    console.error("Review submission error:", error);
    message.textContent =
      error.message || "Unable to submit review.";
  }
}

document
  .getElementById("submitProjectReviewButton")
  .addEventListener("click", submitProjectReview);
async function loadBusinessAnalytics() {
  const message = document.getElementById("analyticsMessage");

  try {
    message.textContent = "Loading business analytics...";

    const {
      data: { user },
      error: userError
    } = await db.auth.getUser();

    if (userError || !user) {
      throw new Error("Please sign in to your administrator account.");
    }

    if (user.app_metadata?.role !== "admin") {
      throw new Error("Administrator access required.");
    }

    const { data, error } = await db.functions.invoke(
      "admin-business-analytics",
      {
        body: {}
      }
    );

    if (error) throw error;

    if (!data?.success || !data.analytics) {
      throw new Error(
        data?.error || "Unable to load analytics."
      );
    }

    const a = data.analytics;

    document.getElementById("totalProjects").textContent =
      a.total_projects;

    document.getElementById("projectsInProgress").textContent =
      a.projects_in_progress;

    document.getElementById("completedProjects").textContent =
      a.completed_projects;

    document.getElementById("unpaidProjects").textContent =
      a.projects_not_marked_paid;

    document.getElementById("verifiedRevenue").textContent =
      "₦" + Number(a.verified_revenue_ngn).toLocaleString(
        "en-NG",
        { maximumFractionDigits: 2 }
      );

    document.getElementById("verifiedPayments").textContent =
      a.verified_payment_count;

    document.getElementById("pendingPayments").textContent =
      a.pending_payment_count;

    document.getElementById("failedPayments").textContent =
      a.failed_payment_count;

    document.getElementById("averageRating").textContent =
      a.average_rating + " / 5";

    document.getElementById("reviewCount").textContent =
      a.review_count;

    // Render monthly revenue.
    const revenueContainer =
      document.getElementById("monthlyRevenue");

    revenueContainer.replaceChildren();

    a.monthly_revenue.forEach((item) => {
      const row = document.createElement("div");
      row.className = "analytics-row";

      const month = document.createElement("span");
      month.textContent = item.month;

      const amount = document.createElement("strong");
      amount.textContent =
        "₦" + Number(item.revenue_ngn).toLocaleString(
          "en-NG",
          { maximumFractionDigits: 2 }
        );

      row.append(month, amount);
      revenueContainer.appendChild(row);
    });

    // Render recent reviews safely.
    const reviewsContainer =
      document.getElementById("recentReviews");

    reviewsContainer.replaceChildren();

    if (!a.recent_reviews.length) {
      const empty = document.createElement("p");
      empty.textContent = "No client reviews yet.";
      reviewsContainer.appendChild(empty);
    } else {
      a.recent_reviews.forEach((review) => {
        const card = document.createElement("article");
        card.className = "review-card";

        const title = document.createElement("h4");
        title.textContent = review.project_title;

        const rating = document.createElement("p");
        rating.textContent =
          "Rating: " + "★".repeat(
            Math.max(0, Math.min(5, Number(review.rating)))
          ) + " (" + review.rating + "/5)";

        const text = document.createElement("p");
        text.textContent =
          review.review_text || "No written comment provided.";

        const date = document.createElement("small");
        date.textContent = new Date(
          review.created_at
        ).toLocaleDateString();

        card.append(title, rating, text, date);
        reviewsContainer.appendChild(card);
      });
    }

    document.getElementById("analyticsUpdated").textContent =
      "Last updated: " +
      new Date(a.generated_at).toLocaleString();

    message.textContent = "Analytics loaded successfully.";
  } catch (error) {
    console.error("Analytics loading error:", error);

    message.textContent =
      error.message || "Could not load business analytics.";
  }
}

document
  .getElementById("refreshAnalytics")
  .addEventListener("click", loadBusinessAnalytics);
let projectPageOffset = 0;
const projectPageSize = 10;
let currentProjectSearch = "";
let currentProjectTotal = 0;

function makeElement(tag, className, text) {
  const element = document.createElement(tag);

  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;

  return element;
}

async function loadAdminProjects() {
  const message = document.getElementById("projectCenterMessage");
  const list = document.getElementById("adminProjectList");

  try {
    message.textContent = "Loading projects...";
    list.replaceChildren();

    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in first.");
    }

    if (user.app_metadata?.role !== "admin") {
      throw new Error("Administrator access required.");
    }

    const { data, error } = await db.functions.invoke(
      "admin-project-center",
      {
        body: {
          action: "list_projects",
          search: currentProjectSearch,
          limit: projectPageSize,
          offset: projectPageOffset
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(data?.error || "Unable to load projects.");
    }

    currentProjectTotal = data.total;

    if (!data.projects.length) {
      list.appendChild(
        makeElement("p", "", "No projects found.")
      );
    }

    data.projects.forEach((project) => {
      const card = makeElement("article", "admin-project-card");

      card.appendChild(
        makeElement("h3", "", project.project_title || "Untitled project")
      );

      card.appendChild(
        makeElement("p", "", "Client: " + (project.client_name || "Not provided"))
      );

      card.appendChild(
        makeElement("p", "", "Email: " + (project.email || "Not provided"))
      );

      card.appendChild(
        makeElement("p", "", "Project ID: " + project.id)
      );

      card.appendChild(
        makeElement("p", "", "Description: " + (project.project_description || "No description"))
      );

      card.appendChild(
        makeElement("p", "", "Project Status: " + (project.status || "Pending"))
      );

      card.appendChild(
        makeElement("p", "", "Completion: " + (project.completion_status || "In Progress"))
      );

      card.appendChild(
        makeElement("p", "", "Payment: " + (project.payment_status || "Unpaid"))
      );

      card.appendChild(
        makeElement(
          "p",
          "",
          "Created: " +
            (project.created_at
              ? new Date(project.created_at).toLocaleString()
              : "Unknown")
        )
      );

      const statusLabel = makeElement("label", "", "Update project status");
      statusLabel.htmlFor = "project-status-" + project.id;

      const statusSelect = document.createElement("select");
      statusSelect.id = "project-status-" + project.id;

      [
        "Pending",
        "In Progress",
        "On Hold",
        "Completed",
        "Cancelled"
      ].forEach((status) => {
        const option = document.createElement("option");
        option.value = status;
        option.textContent = status;
        option.selected = project.status === status;
        statusSelect.appendChild(option);
      });

      card.appendChild(statusLabel);
      card.appendChild(statusSelect);

      const saveButton = makeElement(
        "button",
        "",
        "Save Status"
      );

      saveButton.type = "button";

      saveButton.addEventListener("click", async () => {
        await updateAdminProjectStatus(
          project.id,
          statusSelect.value
        );
      });

      card.appendChild(saveButton);
      list.appendChild(card);
    });

    const currentPage = Math.floor(
      projectPageOffset / projectPageSize
    ) + 1;

    const totalPages = Math.max(
      1,
      Math.ceil(currentProjectTotal / projectPageSize)
    );

    document.getElementById("projectPageInfo").textContent =
      "Page " + currentPage + " of " + totalPages;

    document.getElementById("previousProjectsButton").disabled =
      projectPageOffset === 0;

    document.getElementById("nextProjectsButton").disabled =
      projectPageOffset + projectPageSize >= currentProjectTotal;

    message.textContent =
      "Loaded " + data.projects.length + " project(s).";
  } catch (error) {
    console.error("Project loading error:", error);

    message.textContent =
      error.message || "Could not load projects.";
  }
}

async function updateAdminProjectStatus(projectId, status) {
  const message = document.getElementById("projectCenterMessage");

  try {
    message.textContent = "Updating project status...";

    const { data, error } = await db.functions.invoke(
      "admin-project-center",
      {
        body: {
          action: "update_status",
          project_id: projectId,
          status
        }
      }
    );

    if (error) throw error;

    if (!data?.success) {
      throw new Error(data?.error || "Could not update status.");
    }

    message.textContent = data.message;

    await loadAdminProjects();
  } catch (error) {
    console.error("Status update error:", error);

    message.textContent =
      error.message || "Could not update project status.";
  }
}

document
  .getElementById("searchProjectsButton")
  .addEventListener("click", () => {
    currentProjectSearch =
      document.getElementById("projectSearch").value.trim();

    projectPageOffset = 0;
    loadAdminProjects();
  });

document
  .getElementById("projectSearch")
  .addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      currentProjectSearch = event.target.value.trim();
      projectPageOffset = 0;
      loadAdminProjects();
    }
  });

document
  .getElementById("refreshProjectsButton")
  .addEventListener("click", loadAdminProjects);

document
  .getElementById("previousProjectsButton")
  .addEventListener("click", () => {
    projectPageOffset = Math.max(
      0,
      projectPageOffset - projectPageSize
    );

    loadAdminProjects();
  });

document
  .getElementById("nextProjectsButton")
  .addEventListener("click", () => if (projectPageOffset + projectPageSize < currentProjectTotal) {      projectPageOffset = projectPageSize;loadAdminProjects();        }
}};
async function loadProfessorClientPortal() {
  const message = document.getElementById("clientPortalMessage");
  const projectList = document.getElementById("clientPortalProjectList");
  const notificationList = document.getElementById(
    "clientPortalNotifications"
  );

  try {
    message.textContent = "Loading your projects...";
    projectList.replaceChildren();
    notificationList.replaceChildren();

    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in to view your client portal.");
    }

    // Retrieve only the signed-in client's projects.
    const { data: projects, error: projectsError } = await db
      .from("projects")
      .select(
        "id, project_title, project_description, status, completion_status, payment_status, quoted_amount, currency, quotation_status, deadline, created_at"
      )
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (projectsError) {
      throw new Error("Could not load your projects.");
    }

    const myProjects = projects || [];

    document.getElementById("clientTotalProjects").textContent =
      myProjects.length;

    document.getElementById("clientActiveProjects").textContent =
      myProjects.filter(project =>
        ["Pending", "In Progress", "On Hold"].includes(project.status)
      ).length;

    document.getElementById("clientCompletedProjects").textContent =
      myProjects.filter(project =>
        project.completion_status === "Completed"
      ).length;

    if (!myProjects.length) {
      const empty = document.createElement("p");
      empty.textContent =
        "You have not submitted a project yet.";
      projectList.appendChild(empty);
    }

    myProjects.forEach(project => {
      const card = document.createElement("article");
      card.className = "client-project-card";

      const title = document.createElement("h4");
      title.textContent = project.project_title || "Untitled project";

      const description = document.createElement("p");
      description.textContent =
        project.project_description || "No project description provided.";

      const workflow = document.createElement("p");
      workflow.textContent =
        "Project status: " + (project.status || "Pending");

      const completion = document.createElement("p");
      completion.textContent =
        "Completion: " +
        (project.completion_status || "In Progress");

      const quotation = document.createElement("p");
      const quoteAmount = Number(project.quoted_amount);

      quotation.textContent =
        "Quotation: " +
        (
          Number.isFinite(quoteAmount) && quoteAmount > 0
            ? (project.currency || "NGN") + " " +
              quoteAmount.toLocaleString()
            : "Not yet provided"
        );

      const quoteStatus = document.createElement("p");
      quoteStatus.textContent =
        "Quotation response: " +
        (project.quotation_status || "Not available");

      const payment = document.createElement("p");
      payment.textContent =
        "Payment: " + (project.payment_status || "Unpaid");

      const deadline = document.createElement("p");
      deadline.textContent =
        "Deadline: " +
        (project.deadline
          ? new Date(project.deadline).toLocaleDateString()
          : "Not set");

      const projectId = document.createElement("small");
      projectId.textContent = "Project ID: " + project.id;

      card.append(
        title,
        description,
        workflow,
        completion,
        quotation,
        quoteStatus,
        payment,
        deadline,
        projectId
      );

      projectList.appendChild(card);
    });

    // Retrieve only the signed-in client's notifications.
    const { data: notifications, error: notificationError } = await db
      .from("notifications")
      .select("id, title, message, is_read, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(30);

    if (notificationError) {
      throw new Error("Projects loaded, but notifications could not be retrieved.");
    }

    if (!notifications || notifications.length === 0) {
      const empty = document.createElement("p");
      empty.textContent = "You have no notifications yet.";
      notificationList.appendChild(empty);
    } else {
      notifications.forEach(notification => {
        const card = document.createElement("article");
        card.className = "client-notification-card";

        const title = document.createElement("h4");
        title.textContent = notification.title || "Notification";

        const content = document.createElement("p");
        content.textContent = notification.message || "";

        const date = document.createElement("small");
        date.textContent =
          new Date(notification.created_at).toLocaleString();

        const readStatus = document.createElement("p");
        readStatus.textContent =
          notification.is_read ? "Read" : "Unread";

        card.append(title, content, date, readStatus);
        notificationList.appendChild(card);
      });
    }

    message.textContent =
      "Your client portal has loaded successfully.";
  } catch (error) {
    console.error("Client portal error:", error);
    message.textContent =
      error.message || "Unable to load your client portal.";
  }
}

document
  .getElementById("refreshClientPortal")
  .addEventListener("click", loadProfessorClientPortal);
async function initializeProjectPayment(projectId, button) {
  const originalText = button.textContent;

  try {
    button.disabled = true;
    button.textContent = "Preparing secure checkout...";

    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError || !user) {
      throw new Error("Please sign in before making a payment.");
    }

    const { data, error } = await db.functions.invoke(
      "initialize-payment",
      {
        body: {
          project_id: projectId
        }
      }
    );

    if (error) {
      throw error;
    }

    if (!data || !data.authorization_url) {
      throw new Error(
        data?.error || "Unable to initialize payment."
      );
    }

    // The payment URL must come from the trusted server function.
    const paymentUrl = new URL(data.authorization_url);

    if (
      paymentUrl.protocol !== "https:" ||
      paymentUrl.hostname !== "checkout.paystack.com"
    ) {
      throw new Error("The payment provider returned an invalid checkout URL.");
    }

    window.location.assign(paymentUrl.href);

  } catch (error) {
    console.error("Payment initialization error:", error);

    alert(
      error.message ||
      "Payment could not be started. Please try again."
    );

    button.disabled = false;
    button.textContent = originalText;
  }
}
async function loadProfessorAdminCenter() {
  const message = document.getElementById("adminCenterMessage");
  const refreshButton = document.getElementById("refreshAdminCenter");
  const notificationList = document.getElementById("adminNotificationList");

  if (!message || !refreshButton || !notificationList) return;

  refreshButton.disabled = true;
  message.textContent = "Loading administrator dashboard...";

  try {
    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError) throw authError;

    if (!user || user.app_metadata?.role !== "admin") {
      message.textContent =
        "Access denied. Sign in with your authorized administrator account.";
      return;
    }

    // Use your existing secure admin function.
    const { data, error } = await db.functions.invoke(
      "admin-business-analytics",
      { body: {} }
    );

    if (error) throw error;

    if (!data || data.error) {
      throw new Error(data?.error || "Analytics could not be loaded.");
    }

    /*
      Expected analytics response fields:
      totalProjects
      inProgress
      completed
      unpaidProjects
      pendingPayments
      averageRating

      These are example mappings. If your deployed function uses
      different field names, adjust them to match its real response.
    */

    const setText = (id, value) => {
      const element = document.getElementById(id);
      if (element) element.textContent = String(value ?? 0);
    };

    setText("adminTotalProjects", data.totalProjects);
    setText("adminPendingProjects", data.pendingProjects);
    setText("adminPendingQuotes", data.pendingQuotations);
    setText("adminUnpaidProjects", data.unpaidProjects);
    setText("adminAwaitingReview", data.awaitingClientReview);
    setText("adminCompletedProjects", data.completed);

    // Load recent notifications through a dedicated admin function.
    const { data: notificationData, error: notificationError } =
      await db.functions.invoke("admin-notification-center", {
        body: { action: "recent_notifications" }
      });

    if (notificationError) throw notificationError;

    if (notificationData?.error) {
      throw new Error(notificationData.error);
    }

    notificationList.replaceChildren();

    const notifications = notificationData?.notifications || [];

    if (notifications.length === 0) {
      notificationList.textContent = "No recent notifications.";
    } else {
      notifications.forEach(item => {
        const card = document.createElement("article");
        card.className = "admin-alert-item";

        const title = document.createElement("strong");
        title.textContent = item.title || "Project Notification";

        const body = document.createElement("p");
        body.textContent = item.message || "";

        const date = document.createElement("small");
        date.textContent = item.created_at
          ? new Date(item.created_at).toLocaleString("en-NG")
          : "";

        card.append(title, body, date);
        notificationList.appendChild(card);
      });
    }

    message.textContent = "Administrator dashboard loaded successfully.";

  } catch (error) {
    console.error("Admin dashboard error:", error);

    message.textContent =
      "Dashboard loading failed. Check your Edge Functions, permissions, and database schema.";
  } finally {
    refreshButton.disabled = false;
  }
}

document
  .getElementById("refreshAdminCenter")
  ?.addEventListener("click", loadProfessorAdminCenter);
async function loadProfessorProjectTracker() {
  const list = document.getElementById("projectTrackerList");
  const message = document.getElementById("projectTrackerMessage");
  const refreshButton = document.getElementById("refreshProjectTracker");

  if (!list || !message || !refreshButton) return;

  refreshButton.disabled = true;
  list.replaceChildren();
  message.textContent = "Loading your projects...";

  try {
    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError) throw authError;

    if (!user) {
      message.textContent = "Please sign in to track your projects.";
      return;
    }

    const { data: projects, error } = await db
      .from("projects")
      .select(
        "id, project_title, status, quotation_status, payment_status, completion_status, created_at, deadline"
      )
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw error;

    if (!projects || projects.length === 0) {
      message.textContent = "You have not submitted any projects yet.";
      return;
    }

    message.textContent = "Your project progress is shown below.";

    projects.forEach(project => {
      const card = document.createElement("article");
      card.className = "tracker-project-card";

      const title = document.createElement("h3");
      title.textContent =
        project.project_title || "Software Development Project";

      const created = document.createElement("p");
      created.className = "tracker-project-meta";
      created.textContent =
        "Submitted: " + formatTrackerDate(project.created_at);

      const status = document.createElement("span");
      status.className = "tracker-status-badge";
      status.textContent =
        "Current status: " + (project.completion_status || project.status || "Pending");

      card.append(title, created, status);

      if (project.deadline) {
        const deadline = document.createElement("p");
        deadline.className = "tracker-project-meta";
        deadline.textContent =
          "Target deadline: " + formatTrackerDate(project.deadline);
        card.appendChild(deadline);
      }

      const timeline = document.createElement("div");
      timeline.className = "tracker-timeline";

      const steps = buildProjectTimeline(project);

      steps.forEach((step, index) => {
        const row = document.createElement("div");
        row.className = "tracker-step";

        if (step.done) row.classList.add("completed");
        if (step.current) row.classList.add("current");

        const marker = document.createElement("div");
        marker.className = "tracker-step-marker";
        marker.textContent = step.done ? "✓" : String(index + 1);

        const content = document.createElement("div");
        content.className = "tracker-step-content";

        const heading = document.createElement("strong");
        heading.textContent = step.title;

        const detail = document.createElement("p");
        detail.textContent = step.detail;

        content.append(heading, detail);
        row.append(marker, content);
        timeline.appendChild(row);
      });

      card.appendChild(timeline);
      list.appendChild(card);
    });

  } catch (error) {
    console.error("Project tracker error:", error);
    message.textContent =
      "Could not load projects. Check your sign-in, database permissions, and column names.";
  } finally {
    refreshButton.disabled = false;
  }
}

function buildProjectTimeline(project) {
  const quotation = String(project.quotation_status || "").toLowerCase();
  const payment = String(project.payment_status || "").toLowerCase();
  const completion = String(project.completion_status || "").toLowerCase();
  const workflow = String(project.status || "").toLowerCase();

  const quotePrepared = ["prepared", "accepted", "declined"].includes(quotation);
  const quoteAccepted = quotation === "accepted";
  const paid = payment === "paid";
  const delivered = [
    "awaiting client review",
    "completed"
  ].includes(completion);
  const reviewRequested = completion === "awaiting client review";
  const completed = completion === "completed";

  let currentIndex = 0;

  if (quotePrepared) currentIndex = 1;
  if (quoteAccepted) currentIndex = 2;
  if (paid) currentIndex = 3;

  if (paid && ["in progress", "completed"].includes(workflow)) {
    currentIndex = 4;
  }

  if (delivered) currentIndex = 5;
  if (reviewRequested) currentIndex = 6;
  if (completed) currentIndex = 7;

  const steps = [
    {
      title: "Project Request Submitted",
      detail: "Your request has been recorded."
    },
    {
      title: "Quotation Prepared",
      detail: "The quotation is prepared for your review."
    },
    {
      title: "Quotation Accepted",
      detail: "The quotation has been accepted."
    },
    {
      title: "Payment Confirmed",
      detail: "Payment has been recorded as successful."
    },
    {
      title: "Development in Progress",
      detail: "Your project is moving through development."
    },
    {
      title: "Files Delivered",
      detail: "Your project deliverables have been uploaded."
    },
    {
      title: "Client Review",
      detail: "Review the delivered work and provide feedback."
    },
    {
      title: "Project Completed",
      detail: "The project has been marked as completed."
    }
  ];

  return steps.map((step, index) => {
    let done = index === 0;

    if (index === 1) done = quotePrepared;
    if (index === 2) done = quoteAccepted;
    if (index === 3) done = paid;
    if (index === 4) {
      done = paid && ["in progress", "completed"].includes(workflow);
    }
    if (index === 5) done = delivered;
    if (index === 6) done = completed || reviewRequested;
    if (index === 7) done = completed;

    // A declined quotation should not be presented as accepted.
    let detail = step.detail;

    if (index === 1 && quotation === "declined") {
      detail = "The quotation was declined. Contact the team if you need changes.";
    }

    if (index === 2 && quotation === "declined") {
      detail = "Awaiting a revised quotation or further discussion.";
    }

    if (index === 3 && !paid) {
      detail = "This stage is complete only after payment is verified.";
    }

    return {
      title: step.title,
      detail,
      done,
      current: index === currentIndex && !completed
    };
  });
}

function formatTrackerDate(value) {
  if (!value) return "Not available";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "Not available";

  return date.toLocaleDateString("en-NG", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

document
  .getElementById("refreshProjectTracker")
  ?.addEventListener("click", loadProfessorProjectTracker);
async function loadProjectStatusHistory(projectId) {
  const list = document.getElementById("projectHistoryList");
  const message = document.getElementById("projectHistoryMessage");

  if (!list || !message) return;

  list.replaceChildren();
  message.textContent = "Loading project history...";

  try {
    const {
      data: { user },
      error: authError
    } = await db.auth.getUser();

    if (authError) throw authError;

    if (!user) {
      message.textContent = "Please sign in to view project history.";
      return;
    }

    if (typeof projectId !== "string" || !projectId) {
      message.textContent = "Select a valid project.";
      return;
    }

    // Confirm that the selected project belongs to the signed-in client.
    const { data: project, error: projectError } = await db
      .from("projects")
      .select("id")
      .eq("id", projectId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (projectError) throw projectError;

    if (!project) {
      message.textContent = "Project not found or access denied.";
      return;
    }

    const { data: events, error } = await db
      .from("project_status_history")
      .select(
        "event_type, old_status, new_status, event_description, created_at"
      )
      .eq("project_id", projectId)
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) throw error;

    if (!events || events.length === 0) {
      message.textContent =
        "No activity history has been recorded for this project yet.";
      return;
    }

    message.textContent = "Recent project activity:";

    events.forEach(event => {
      const item = document.createElement("article");
      item.className = "project-history-item";

      const title = document.createElement("strong");
      title.textContent = String(event.event_type || "Project update")
        .replaceAll("_", " ")
        .replace(/\b\w/g, character => character.toUpperCase());

      const description = document.createElement("p");
      description.textContent = event.event_description || "";

      const date = document.createElement("time");

      if (event.created_at) {
        const timestamp = new Date(event.created_at);

        date.dateTime = event.created_at;
        date.textContent = Number.isNaN(timestamp.getTime())
          ? "Date unavailable"
          : timestamp.toLocaleString("en-NG");
      }

      item.append(title, description, date);
      list.appendChild(item);
    });

  } catch (error) {
    console.error("Project history loading error:", error);
    message.textContent =
      "Unable to load history. Check your database policies and table setup.";
  }
}
async function loadSupportProjects() {
  const select = document.getElementById("supportProjectSelect");
  const status = document.getElementById("supportStatus");

  try {
    const { data: { user }, error: authError } =
      await db.auth.getUser();

    if (authError) throw authError;

    if (!user) {
      select.replaceChildren(new Option("Please sign in first", ""));
      return;
    }

    const { data: projects, error } = await db
      .from("projects")
      .select("id, project_title")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) throw error;

    select.replaceChildren(
      new Option("Select a project", "")
    );

    (projects || []).forEach(project => {
      select.add(
        new Option(
          project.project_title || "Software Development Project",
          project.id
        )
      );
    });

    if (!projects || projects.length === 0) {
      status.textContent = "Submit a project request before starting a conversation.";
    }
  } catch (error) {
    console.error("Support projects error:", error);
    status.textContent = "Could not load your projects.";
  }
}

async function loadSupportMessages(projectId) {
  const container = document.getElementById("supportMessages");
  container.replaceChildren();

  if (!projectId) {
    container.textContent = "Select a project to view its conversation.";
    return;
  }

  try {
    const { data: { user }, error: authError } =
      await db.auth.getUser();

    if (authError) throw authError;

    if (!user) {
      container.textContent = "Please sign in first.";
      return;
    }

    const { data: project, error: projectError } = await db
      .from("projects")
      .select("id")
      .eq("id", projectId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (projectError) throw projectError;

    if (!project) {
      container.textContent = "Project not found or access denied.";
      return;
    }

    const { data: messages, error } = await db
      .from("support_messages")
      .select("sender_id, message, created_at")
      .eq("project_id", projectId)
      .order("created_at", { ascending: true })
      .limit(100);

    if (error) throw error;

    if (!messages || messages.length === 0) {
      container.textContent = "No messages yet. Send your first message below.";
      return;
    }

    messages.forEach(item => {
      const card = document.createElement("article");
      const isAdminMessage = item.sender_id !== user.id;

      card.className =
        "support-message " +
        (isAdminMessage ? "admin-message" : "client-message");

      const sender = document.createElement("strong");
      sender.textContent = isAdminMessage ? "Professor Coder Support" : "You";

      const content = document.createElement("p");
      content.textContent = item.message;

      const date = document.createElement("small");
      date.textContent = item.created_at
        ? new Date(item.created_at).toLocaleString("en-NG")
        : "";

      card.append(sender, content, date);
      container.appendChild(card);
    });

    container.scrollTop = container.scrollHeight;

  } catch (error) {
    console.error("Support messages error:", error);
    container.textContent =
      "Could not load messages. Check your database permissions.";
  }
}

document
  .getElementById("supportProjectSelect")
  .addEventListener("change", event => {
    loadSupportMessages(event.target.value);
  });

document
  .getElementById("supportMessageForm")
  .addEventListener("submit", async event => {
    event.preventDefault();

    const projectId =
      document.getElementById("supportProjectSelect").value;

    const input = document.getElementById("supportMessageInput");
    const button = document.getElementById("supportSendButton");
    const status = document.getElementById("supportStatus");

    const message = input.value.trim();

    if (!projectId) {
      status.textContent = "Please select a project.";
      return;
    }

    if (!message || message.length > 3000) {
      status.textContent = "Enter a message of 1–3000 characters.";
      return;
    }

    button.disabled = true;
    status.textContent = "Sending message...";

    try {
      const { data, error } = await db.functions.invoke(
        "project-support",
        {
          body: {
            project_id: projectId,
            message
          }
        }
      );

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || "Message could not be sent.");
      }

      input.value = "";
      status.textContent = "Message sent successfully.";

      await loadSupportMessages(projectId);

    } catch (error) {
      console.error("Send support message error:", error);
      status.textContent =
        error.message || "Could not send your message.";
    } finally {
      button.disabled = false;
    }
  });

loadSupportProjects();
let selectedAdminSupportProject = null;

const adminSupportStatus =
  document.getElementById("adminSupportStatus");

const adminSupportConversations =
  document.getElementById("adminSupportConversations");

const adminSupportMessages =
  document.getElementById("adminSupportMessages");

function setAdminSupportStatus(message) {
  adminSupportStatus.textContent = message;
}

async function callAdminSupportInbox(action, extra = {}) {
  const { data: sessionData } = await db.auth.getSession();
  const session = sessionData.session;

  if (!session) {
    throw new Error("Please sign in first.");
  }

  if (session.user.app_metadata?.role !== "admin") {
    throw new Error("Administrator access is required.");
  }

  const { data, error } = await db.functions.invoke(
    "admin-support-inbox",
    {
      body: { action, ...extra }
    }
  );

  if (error) throw error;
  if (data?.error) throw new Error(data.error);

  return data;
}

async function loadAdminSupportConversations() {
  try {
    setAdminSupportStatus("Loading conversations...");

    const data = await callAdminSupportInbox("list_conversations");

    adminSupportConversations.replaceChildren();

    if (!data.conversations?.length) {
      adminSupportConversations.textContent =
        "No support conversations found yet.";
      setAdminSupportStatus("");
      return;
    }

    data.conversations.forEach((conversation) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "admin-conversation";

      const title = document.createElement("strong");
      title.textContent =
        conversation.project_title || "Untitled project";

      const details = document.createElement("small");
      details.textContent =
        `${conversation.client_name || "Client"} · ` +
        `${conversation.unread_count || 0} unread`;

      const preview = document.createElement("small");
      preview.textContent = conversation.latest_message || "";

      button.append(title, details, preview);

      button.addEventListener("click", () => {
        openAdminSupportConversation(conversation);
      });

      adminSupportConversations.appendChild(button);
    });

    setAdminSupportStatus("Conversations loaded.");
  } catch (error) {
    console.error(error);
    setAdminSupportStatus(error.message || "Unable to load inbox.");
  }
}

async function openAdminSupportConversation(conversation) {
  try {
    selectedAdminSupportProject = conversation.id;

    document.getElementById("adminSupportProjectTitle").textContent =
      `${conversation.project_title || "Project"} — ` +
      `${conversation.client_name || "Client"}`;

    adminSupportMessages.textContent = "Loading messages...";

    const data = await callAdminSupportInbox("get_messages", {
      project_id: conversation.id
    });

    adminSupportMessages.replaceChildren();

    const { data: currentUserData } = await db.auth.getUser();
    const currentUserId = currentUserData.user?.id;

    (data.messages || []).forEach((message) => {
      const box = document.createElement("div");

      box.className = "admin-chat-message" +
        (message.sender_id === currentUserId ? " admin-reply" : "");

      const sender = document.createElement("strong");
      sender.textContent =
        message.sender_id === currentUserId ? "You (Admin)" : "Client";

      const content = document.createElement("div");
      content.textContent = message.message;

      const time = document.createElement("time");
      time.textContent = new Date(message.created_at).toLocaleString();

      box.append(sender, content, time);
      adminSupportMessages.appendChild(box);
    });

    await callAdminSupportInbox("mark_read", {
      project_id: conversation.id
    });

    await loadAdminSupportConversations();
  } catch (error) {
    console.error(error);
    adminSupportMessages.textContent =
      "Unable to load messages. Please try again.";
    setAdminSupportStatus(error.message || "Message loading failed.");
  }
}

document
  .getElementById("refreshSupportInbox")
  .addEventListener("click", loadAdminSupportConversations);

document
  .getElementById("adminSupportReplyForm")
  .addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!selectedAdminSupportProject) {
      setAdminSupportStatus("Select a client conversation first.");
      return;
    }

    const input = document.getElementById("adminSupportReply");
    const button = document.getElementById("adminSupportSend");
    const message = input.value.trim();

    if (!message) return;

    button.disabled = true;

    try {
      // Uses your existing project-support Edge Function.
      const { data: sessionData } = await db.auth.getSession();

      if (!sessionData.session) {
        throw new Error("Please sign in again.");
      }

      const { data, error } = await db.functions.invoke(
        "project-support",
        {
          body: {
            project_id: selectedAdminSupportProject,
            message
          }
        }
      );

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      input.value = "";
      setAdminSupportStatus("Reply sent successfully.");

      await openAdminSupportConversation({
        id: selectedAdminSupportProject,
        project_title:
          document.getElementById("adminSupportProjectTitle").textContent
      });
    } catch (error) {
      console.error(error);
      setAdminSupportStatus(error.message || "Unable to send reply.");
    } finally {
      button.disabled = false;
    }
  });

// Load the inbox when an administrator is already signed in.
db.auth.getSession().then(({ data }) => {
  if (data.session?.user?.app_metadata?.role === "admin") {
    loadAdminSupportConversations();
  }
});

// Also refresh when the authentication state changes.
db.auth.onAuthStateChange((_event, session) => {
  if (session?.user?.app_metadata?.role === "admin") {
    loadAdminSupportConversations();
  }
});
const timelineProjectSelect =
  document.getElementById("timelineProjectSelect");

const timelineEvents =
  document.getElementById("timelineEvents");

const timelineStatus =
  document.getElementById("timelineStatus");

let timelineCurrentUser = null;

function setTimelineStatus(message) {
  timelineStatus.textContent = message;
}

function formatTimelineDate(dateString) {
  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) {
    return "Date unavailable";
  }

  return date.toLocaleString();
}

async function loadTimelineProjects() {
  try {
    setTimelineStatus("Loading your projects...");

    const { data: sessionData, error: sessionError } =
      await db.auth.getSession();

    if (sessionError) throw sessionError;

    const session = sessionData.session;

    if (!session) {
      timelineProjectSelect.replaceChildren();

      const option = document.createElement("option");
      option.value = "";
      option.textContent = "Please sign in first";

      timelineProjectSelect.appendChild(option);
      timelineEvents.textContent =
        "Sign in to view your project timeline.";

      setTimelineStatus("");
      return;
    }

    timelineCurrentUser = session.user;

    const { data: projects, error } = await db
      .from("projects")
      .select("id, project_title, status, created_at")
      .eq("user_id", session.user.id)
      .order("created_at", { ascending: false });

    if (error) throw error;

    timelineProjectSelect.replaceChildren();

    if (!projects || projects.length === 0) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No projects found";

      timelineProjectSelect.appendChild(option);
      timelineEvents.textContent =
        "Your project activity will appear here after you submit a project.";

      setTimelineStatus("");
      return;
    }

    projects.forEach((project) => {
      const option = document.createElement("option");

      option.value = project.id;
      option.textContent =
        project.project_title || "Untitled project";

      timelineProjectSelect.appendChild(option);
    });

    setTimelineStatus("Projects loaded.");

    await loadTimelineEvents(projects[0].id);
  } catch (error) {
    console.error("Timeline project loading failed:", error);
    setTimelineStatus(
      error.message || "Unable to load projects."
    );
  }
}

async function loadTimelineEvents(projectId) {
  if (!timelineCurrentUser || !projectId) return;

  try {
    timelineEvents.textContent = "Loading project activity...";

    // Verify ownership before loading the history.
    const { data: project, error: projectError } = await db
      .from("projects")
      .select("id, user_id, project_title, status, created_at")
      .eq("id", projectId)
      .eq("user_id", timelineCurrentUser.id)
      .maybeSingle();

    if (projectError) throw projectError;

    if (!project) {
      timelineEvents.textContent =
        "This project was not found in your account.";
      return;
    }

    const { data: history, error: historyError } = await db
      .from("project_status_history")
      .select(
        "id, event_type, old_status, new_status, event_description, created_at"
      )
      .eq("project_id", projectId)
      .order("created_at", { ascending: true })
      .limit(100);

    if (historyError) throw historyError;

    timelineEvents.replaceChildren();

    // Display the original project submission if history has no entry.
    const events = [...(history || [])];

    if (
      !events.some((event) => event.event_type === "project_submitted")
    ) {
      events.unshift({
        id: "project-created",
        event_type: "project_submitted",
        event_description: "Your project request was received.",
        created_at: project.created_at
      });
    }

    if (events.length === 0) {
      timelineEvents.textContent =
        "No activity has been recorded yet.";
      return;
    }

    events.forEach((event, index) => {
      const item = document.createElement("article");
      item.className = "timeline-event";

      const type = (event.event_type || "").toLowerCase();

      if (
        type.includes("completed") ||
        type.includes("confirmed") ||
        type.includes("accepted")
      ) {
        item.classList.add("timeline-success");
      } else if (index === events.length - 1) {
        item.classList.add("timeline-current");
      }

      const heading = document.createElement("h3");

      heading.textContent = (event.event_type || "Project update")
        .replaceAll("_", " ")
        .replace(/\b\w/g, (letter) => letter.toUpperCase());

      const description = document.createElement("p");

      description.textContent =
        event.event_description ||
        (
          event.old_status || event.new_status
            ? `Status: ${event.old_status || "Not specified"} → ${
                event.new_status || "Not specified"
              }`
            : "A project update was recorded."
        );

      const time = document.createElement("time");

      time.textContent = formatTimelineDate(event.created_at);

      item.append(heading, description, time);
      timelineEvents.appendChild(item);
    });

    setTimelineStatus(
      `Showing activity for ${project.project_title || "your project"}.`
    );
  } catch (error) {
    console.error("Timeline event loading failed:", error);

    timelineEvents.textContent =
      "Unable to load project activity. Please try again.";

    setTimelineStatus(
      error.message || "Unable to load timeline."
    );
  }
}

timelineProjectSelect.addEventListener("change", () => {
  loadTimelineEvents(timelineProjectSelect.value);
});

loadTimelineProjects();

db.auth.onAuthStateChange((_event, session) => {
  timelineCurrentUser = session?.user || null;

  if (session) {
    loadTimelineProjects();
  } else {
    timelineProjectSelect.replaceChildren();
    timelineEvents.textContent = "Please sign in to view your projects.";
    setTimelineStatus("");
  }
});
const notificationStatus =
  document.getElementById("notificationDashboardStatus");

const notificationRows =
  document.getElementById("notificationDashboardRows");

function setNotificationStatus(message) {
  notificationStatus.textContent = message;
}

async function loadAdminNotificationDashboard() {
  const refreshButton =
    document.getElementById("refreshNotificationDashboard");

  try {
    refreshButton.disabled = true;
    setNotificationStatus("Loading notification records...");

    const { data: sessionData, error: sessionError } =
      await db.auth.getSession();

    if (sessionError) throw sessionError;

    const session = sessionData.session;

    if (!session) {
      throw new Error("Please sign in first.");
    }

    if (session.user.app_metadata?.role !== "admin") {
      throw new Error("Administrator access is required.");
    }

    const { data, error } = await db.functions.invoke(
      "admin-notification-dashboard",
      { body: {} }
    );

    if (error) throw error;
    if (data?.error) throw new Error(data.error);

    document.getElementById("notificationPending").textContent =
      data.stats.pending;

    document.getElementById("notificationSent").textContent =
      data.stats.sent;

    document.getElementById("notificationFailed").textContent =
      data.stats.failed;

    notificationRows.replaceChildren();

    if (!data.notifications.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");

      cell.colSpan = 5;
      cell.textContent = "No notification records found.";

      row.appendChild(cell);
      notificationRows.appendChild(row);
    }

    data.notifications.forEach((notification) => {
      const row = document.createElement("tr");

      const values = [
        notification.event_type.replaceAll("_", " "),
        notification.recipient_email,
        notification.status,
        String(notification.attempts),
        new Date(notification.created_at).toLocaleString()
      ];

      values.forEach((value) => {
  const cell = document.createElement("td");
  cell.textContent = value;
  row.appendChild(cell);
});

const actionCell = document.createElement("td");

if (
  notification.status === "failed" &&
  notification.attempts < 5
) {
  const retryButton = document.createElement("button");

  retryButton.type = "button";
  retryButton.textContent = "Retry";

  retryButton.addEventListener("click", async () => {
    retryButton.disabled = true;

    try {
      const { data, error } = await db.functions.invoke(
        "admin-retry-notification",
        {
          body: {
            notification_id: notification.id
          }
        }
      );

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      alert("Notification queued for retry.");
      await loadAdminNotificationDashboard();
    } catch (error) {
      console.error(error);
      alert(error.message || "Retry failed.");
      retryButton.disabled = false;
    }
  });

  actionCell.appendChild(retryButton);
} else {
  actionCell.textContent = "—";
}

row.appendChild(actionCell);

      notificationRows.appendChild(row);
    });

    setNotificationStatus("Notification records loaded.");
  } catch (error) {
    console.error(error);
    setNotificationStatus(
      error.message || "Unable to load notifications."
    );
  } finally {
    refreshButton.disabled = false;
  }
}

document
  .getElementById("refreshNotificationDashboard")
  .addEventListener("click", loadAdminNotificationDashboard);
const auditButton = document.getElementById("loadAuditLogBtn");
const auditRows = document.getElementById("auditLogRows");
const auditMessage = document.getElementById("auditLogMessage");

function makeAuditCell(value) {
  const cell = document.createElement("td");
  cell.textContent = value ?? "—";
  return cell;
}

async function loadAdminAuditLog() {
  auditMessage.textContent = "Loading audit records...";
  auditRows.replaceChildren();

  try {
    const { data, error } = await db.functions.invoke(
      "admin-audit-log",
      {
        body: { action: "list" }
      }
    );

    if (error) throw error;

    const records = data?.records ?? [];

    if (!records.length) {
      auditRows.innerHTML =
        '<tr><td colspan="6">No audit records found yet.</td></tr>';

      auditMessage.textContent = "Audit log loaded.";
      return;
    }

    records.forEach((record) => {
      const row = document.createElement("tr");

      row.appendChild(
        makeAuditCell(
          new Date(record.created_at).toLocaleString()
        )
      );

      row.appendChild(makeAuditCell(record.actor_id));
      row.appendChild(makeAuditCell(record.action));
      row.appendChild(makeAuditCell(record.entity_type));
      row.appendChild(makeAuditCell(record.entity_id));

      const detailsCell = document.createElement("td");
      const details = document.createElement("pre");

      details.textContent = JSON.stringify(
        record.details ?? {},
        null,
        2
      );

      details.style.whiteSpace = "pre-wrap";
      details.style.maxWidth = "280px";
      detailsCell.appendChild(details);
      row.appendChild(detailsCell);

      auditRows.appendChild(row);
    });

    auditMessage.textContent =
      `${records.length} audit record(s) loaded.`;
  } catch (error) {
    console.error("Audit log error:", error);
    auditMessage.textContent =
      "Unable to load audit records. Check your admin access and Edge Function deployment.";
  }
}

auditButton?.addEventListener("click", loadAdminAuditLog);